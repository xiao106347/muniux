
#!/bin/bash
#
#scalable folders
./replace_folder_file.sh ../places/scalable/folder-development.svg
./replace_folder_file.sh ../places/scalable/folder-documents.svg
./replace_folder_file.sh ../places/scalable/folder-download.svg
./replace_folder_file.sh ../places/scalable/folder-dropbox.svg
./replace_folder_file.sh ../places/scalable/folder-music.svg
./replace_folder_file.sh ../places/scalable/folder-pictures.svg
./replace_folder_file.sh ../places/scalable/folder-publicshare.svg
./replace_folder_file.sh ../places/scalable/folder-remote.svg
./replace_folder_file.sh ../places/scalable/folder-saved-search.svg
./replace_folder_file.sh ../places/scalable/folder.svg
./replace_folder_file.sh ../places/scalable/folder-templates.svg
./replace_folder_file.sh ../places/scalable/folder-ubuntuone.svg
./replace_folder_file.sh ../places/scalable/folder-videos.svg
./replace_folder_file.sh ../places/scalable/folder-virtualbox.svg
./replace_folder_file.sh ../places/scalable/folder-wine.svg
./replace_folder_file.sh ../places/scalable/user-home.svg
#small folders
./replace_folder_file.sh ../places/small/folder-development.svg
./replace_folder_file.sh ../places/small/folder-documents.svg
./replace_folder_file.sh ../places/small/folder-download.svg
./replace_folder_file.sh ../places/small/folder-dropbox.svg
./replace_folder_file.sh ../places/small/folder-music.svg
./replace_folder_file.sh ../places/small/folder-pictures.svg
./replace_folder_file.sh ../places/small/folder-publicshare.svg
./replace_folder_file.sh ../places/small/folder-remote.svg
./replace_folder_file.sh ../places/small/folder-saved-search.svg
./replace_folder_file.sh ../places/small/folder.svg
./replace_folder_file.sh ../places/small/folder-templates.svg
./replace_folder_file.sh ../places/small/folder-ubuntuone.svg
./replace_folder_file.sh ../places/small/folder-videos.svg
./replace_folder_file.sh ../places/small/folder-virtualbox.svg
./replace_folder_file.sh ../places/small/folder-wine.svg
./replace_folder_file.sh ../places/small/user-home.svg
